# Session Log - Sketch Matcher (Pi)

Tracks the current state and the next steps. Update checkboxes as work progresses.

## Current status (2026-08-05)

Local environment is fully set up and validated. All dependencies installed in
`sketch_matcher_env` (Python 3.13.9) and `final_verification.py` passes.

- [x] Create venv `sketch_matcher_env`
- [x] Install requirements-gpu.txt (tensorflow 2.21.0, opencv-python 5.0.0.93, numpy 2.5.1, scikit-learn 1.9.0, tqdm 4.70.0, kagglehub 1.0.2, requests 2.34.2)
- [x] Run `final_verification.py` -> "All checks passed - ready for HPC"
- [x] Local compile check: `python -m py_compile src/*.py` (all 9 modules compile OK)

## Windows PowerShell gotchas (learned)

- Activate with the correct Windows path (NOT `bin\`, NOT `.venv\Scripts\activate`):
  `.\sketch_matcher_env\Scripts\Activate.ps1`
- Or skip activation and call the venv python directly:
  `.\sketch_matcher_env\Scripts\python.exe <script>`
- PowerShell does NOT support `&&`; use `;` between commands.

## HPC setup (10.10.11.201)

- [x] Get HPC credentials from NITJ (user `ee_24126016`, expires 2026-08-21; password never stored in files)
- [x] Verified reachable: 10.10.11.201:22 OPEN; password-only login (no key) as of 2026-08-06
- [ ] USER STEP (once): install SSH key so the AI can drive everything — in your own PowerShell:
      `type $env:USERPROFILE\.ssh\id_ed25519_hpc.pub | ssh ee_24126016@10.10.11.201 "mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys && echo KEY_INSTALLED"`
- [ ] Upload `hpc/setup_env.sh` to HPC home + run it (creates conda env `sketch_matcher` py3.10, pip installs incl. kagglehub, verifies TF)
- [ ] Upload project to `/Data/ee_24126016/sketch_matcher` (run from /Data, NOT home — home is purged)
- [ ] Upload kaggle.json to `~/.kaggle/kaggle.json` (REQUIRED now — datasets download on HPC, not locally)

## Training pipeline (run IN ORDER)

- [ ] `qsub hpc/job_gpu_test.pbs`     (workq, ~2 min sanity: TF sees H100 MIG? check gpu_test.log)
- [ ] `qsub hpc/job_preprocess.pbs`   (cpuq, downloads Kaggle data + preprocess, ~2-4h, walltime 24h)
- [ ] `qstat -u ee_24126016` wait until R/finished
- [ ] `qsub hpc/job_train.pbs`        (workq, GPU teacher+student, ~2-4 days)
- [ ] `qsub hpc/job_finalize.pbs`     (cpuq, evaluate + export TFLite, ~1h)

Debug: `tracejob <JobID>`, `cat gpu_test.log / preprocess.log / train.log / finalize.log`
OOM on small MIG slice -> uncomment SKETCH_BATCH1/2/3 in hpc/job_train.pbs.

## Pull results + deploy

- [ ] `scp -r ee_24126016@10.10.11.201:/Data/ee_24126016/sketch_matcher/models/ .`
- [ ] `scp -r ee_24126016@10.10.11.201:/Data/ee_24126016/sketch_matcher/pi_deploy/model_data/ .`
- [ ] Copy tflite + photo_embeddings.npy + labels.json into pi_deploy/model_data/
- [ ] Run `pi_deploy/main.py` on the Pi

## Key rules

- workq = GPU only (CPU jobs auto-killed); finalize runs in cpuq on purpose.
- 1 GPU (MIG slice) per user at a time; set `CUDA_VISIBLE_DEVICES` to the MIG UUID from `nvidia-smi -L`.
- `pip install "tensorflow[and-cuda]"` (NOT plain tensorflow); in PBS: `source /apps/compilers/anaconda3/etc/profile.d/conda.sh`, `export PYTHONNOUSERSITE=1`, use `$CONDA_PREFIX/bin/python`.
- Big data lives in /Data, never home (home purged after 15 days).
- job_train.pbs walltime = 120h; if cluster rejects >24h, split teacher/student phases.

See hpc/RUNBOOK.md for the full HPC reference.
